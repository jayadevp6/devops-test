#!/bin/bash

function install_jenkins() {
    sudo apt update
    sudo apt install -y openjdk-8-jdk
    wget -q -O - https://pkg.jenkins.io/debian/jenkins.io.key | sudo apt-key add -
    sudo sh -c 'echo deb http://pkg.jenkins.io/debian-stable binary/ > /etc/apt/sources.list.d/jenkins.list'
    sudo apt update
    sudo apt install -y jenkins
    sudo ufw allow 8080
}



function install_aws_cli() {
  export AWSCLI_VERSION=2.1.29
  cd /tmp
  curl -fsSL "https://awscli.amazonaws.com/awscli-exe-linux-x86_64-$AWSCLI_VERSION.zip" -o "awscli.zip"
  unzip awscli.zip
  sudo ./aws/install
  cd /tmp
  rm -rf aws
}
function install_docker() {
      sudo apt install apt-transport-https ca-certificates curl software-properties-common
      curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
      sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable"
      sudo apt update
      apt-cache policy docker-ce -y 
      sudo apt install docker-ce -y
}


function main() {
  install_jenkins
  install_aws_cli
  install_docker

}

main


